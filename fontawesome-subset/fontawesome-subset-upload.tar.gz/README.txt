FontAwesome 7.2.0 subset for aun-projector.com.bd
Generated 2026-08-29 from the 70 icons actually used across 18 crawled pages.

  fa-solid-900.woff2    114,740 -> 6,656 bytes
  fa-brands-400.woff2   110,088 -> 1,080 bytes
  fa-regular-400.woff2   18,924 -> 2,148 bytes
  TOTAL                 243,752 -> 9,884 bytes   (228 KB saved)

INSTALL
  Target: wp-content/uploads/fontawesome/webfonts/

  1. BACK UP FIRST. In cPanel File Manager, select the three existing
     .woff2 files, Compress -> zip, name it webfonts-ORIGINAL.zip.
     Keep that zip. It is your one-click rollback.
  2. Upload these three files, overwriting the originals.
     Filenames are identical, so no CSS change is needed.
  3. Clear WP Rocket cache, then Cloudflare cache (Purge Everything).
  4. Hard-refresh the site (Ctrl+Shift+R) and check icons.

WHAT TO CHECK
  Home, shop, a product page, cart, checkout, warranty register,
  repair status, contact, and the Bangla (/bn/) versions.
  A missing icon shows as a blank box or a small rectangle.

IF AN ICON IS MISSING
  It is on a page that was not crawled. Send me the page URL and the
  icon and I will regenerate including it. Or restore the zip from
  step 1 to revert instantly.

NOT INCLUDED / STILL TO DO
  - Revolution Slider loads its own separate FontAwesome copy from
    wp-content/plugins/revslider/public/css/fonts/font-awesome/
  - wp-content/uploads/font-awesome/ appears to be an unused duplicate
    folder (returns 404 for the paths the site references).
